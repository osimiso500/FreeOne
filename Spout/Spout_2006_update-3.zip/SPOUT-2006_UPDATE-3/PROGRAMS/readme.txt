Most Spout plugins are built into other applications. Only the plugin for Winamp Milkdrop remains in the Spout distribution.

These plugins were previously included but can now be found elsewhere :

MAX/MSP

jit.gl.spoutsender and jit.gl.spoutreceiver are available in the Max package manager
for both 32bit and 64bit. Max provides help files as examples.

PROCESSING

Spout for Processing is available as a contributed library.
Get it from your sketch Library import manager.
Examples are included in the distribution.
Source is available on GitHub : https://github.com/leadedge/SpoutProcessing

FREEFRAMEGL

Freeframe hosts for popular programs now include Spout built in and the 32 bit plugins are no longer necessary. However, source remains available on GitHub : https://github.com/leadedge/Spout2

VVVV
DX9 version is distributed with the latest Alphas. DX11 version avaliable as an addition.

VIRTUALDJ

64 bit plugins are available on GitHub : https://github.com/leadedge/SpoutVDJ
The receiver is experimantal and not recommended for performance work.


